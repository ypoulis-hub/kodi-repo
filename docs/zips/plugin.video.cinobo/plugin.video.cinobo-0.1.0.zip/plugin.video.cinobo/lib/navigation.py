"""Menu routing and list building for the Cinobo add-on."""

import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from . import api, auth, player

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')


def log(msg):
    xbmc.log('[Cinobo] nav: {}'.format(msg), xbmc.LOGINFO)


class Router:
    def __init__(self, handle, base_url):
        self.handle = handle
        self.base_url = base_url

    def url(self, **kwargs):
        return '{}?{}'.format(self.base_url, urllib.parse.urlencode(kwargs))

    # -------------------------------------------------------------- dispatch

    def route(self, params):
        action = params.get('action', 'home')
        log('route action={}'.format(action))
        handlers = {
            'home': self.home,
            'rows': self.rows,
            'browse': lambda: self.browse(params.get('id', ''),
                                          params.get('after', ''),
                                          params.get('title', '')),
            'collections': lambda: self.nav_group(0, 'Συλλογές'),
            'filmographies': lambda: self.nav_group(1, 'Φιλμογραφίες'),
            'watchlist': self.watchlist,
            'continue': self.continue_watching,
            'search': self.search,
            'show': lambda: self.show(params.get('custom', '')),
            'play': lambda: player.play(self.handle,
                                        custom_id=params.get('custom', ''),
                                        playable_id=params.get('playable', ''),
                                        title=params.get('title', ''),
                                        offset=int(params.get('offset', '0') or 0)),
            'mylist': lambda: self.toggle_mylist(params.get('magine', ''),
                                                 params.get('add', '1') == '1'),
            'login': self.do_login,
            'logout': self.do_logout,
            'settings': lambda: ADDON.openSettings(),
        }
        (handlers.get(action) or self.home)()

    # ----------------------------------------------------------------- menus

    def home(self):
        entries = [
            ('Αρχική', 'rows', 'DefaultFolder.png'),
            ('Συλλογές', 'collections', 'DefaultGenre.png'),
            ('Φιλμογραφίες', 'filmographies', 'DefaultDirector.png'),
            ('Η λίστα μου', 'watchlist', 'DefaultPlaylist.png'),
            ('Συνέχισε να βλέπεις', 'continue', 'DefaultInProgressShows.png'),
            ('Αναζήτηση', 'search', 'DefaultAddonsSearch.png'),
        ]
        for label, act, icon in entries:
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': icon})
            xbmcplugin.addDirectoryItem(
                self.handle, self.url(action=act), li, isFolder=True)

        # Account row
        if auth.is_authenticated():
            li = xbmcgui.ListItem(label='[Αποσύνδεση]')
            xbmcplugin.addDirectoryItem(self.handle, self.url(action='logout'),
                                        li, isFolder=False)
        else:
            li = xbmcgui.ListItem(label='[Σύνδεση]')
            xbmcplugin.addDirectoryItem(self.handle, self.url(action='login'),
                                        li, isFolder=False)
        xbmcplugin.setContent(self.handle, 'files')
        xbmcplugin.endOfDirectory(self.handle)

    def rows(self):
        if not auth.require_auth():
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        try:
            rows = api.get_home()
        except Exception as e:
            return self._error(e)
        for row in rows:
            if not row.get('id'):
                continue
            li = xbmcgui.ListItem(label=row['title'] or '—')
            xbmcplugin.addDirectoryItem(
                self.handle,
                self.url(action='browse', id=row['id'], title=row['title']),
                li, isFolder=True)
        xbmcplugin.setContent(self.handle, 'files')
        xbmcplugin.endOfDirectory(self.handle)

    def browse(self, block_id, after, title):
        if not block_id or not auth.require_auth():
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        try:
            items, nxt = api.get_block(block_id, after=after or None)
        except Exception as e:
            return self._error(e)
        self._add_items(items)
        if nxt:
            li = xbmcgui.ListItem(label='» Επόμενη σελίδα')
            xbmcplugin.addDirectoryItem(
                self.handle,
                self.url(action='browse', id=block_id, after=nxt, title=title),
                li, isFolder=True)
        xbmcplugin.setContent(self.handle, 'movies')
        if title:
            xbmcplugin.setPluginCategory(self.handle, title)
        xbmcplugin.endOfDirectory(self.handle)

    def nav_group(self, index, title):
        try:
            groups = api.get_navigation('el')
        except Exception as e:
            return self._error(e)
        if index >= len(groups):
            return xbmcplugin.endOfDirectory(self.handle)
        for link in groups[index]['links']:
            li = xbmcgui.ListItem(label=link['title'])
            if link.get('image'):
                li.setArt({'thumb': link['image'], 'fanart': link['image']})
            xbmcplugin.addDirectoryItem(
                self.handle,
                self.url(action='browse', id=link['magineId'],
                         title=link['title']),
                li, isFolder=True)
        xbmcplugin.setContent(self.handle, 'files')
        xbmcplugin.setPluginCategory(self.handle, title)
        xbmcplugin.endOfDirectory(self.handle)

    def watchlist(self):
        if not auth.require_auth():
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        try:
            items = api.get_watchlist()
        except Exception as e:
            return self._error(e)
        if not items:
            self._notify('Η λίστα σου είναι άδεια.')
        self._add_items(items)
        xbmcplugin.setContent(self.handle, 'movies')
        xbmcplugin.endOfDirectory(self.handle)

    def continue_watching(self):
        if not auth.require_auth():
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        try:
            items = api.get_continue_watching()
        except Exception as e:
            return self._error(e)
        if not items:
            self._notify('Δεν υπάρχει κάτι σε εξέλιξη.')
        self._add_items(items)
        xbmcplugin.setContent(self.handle, 'movies')
        xbmcplugin.endOfDirectory(self.handle)

    def search(self):
        kb = xbmc.Keyboard('', 'Αναζήτηση Cinobo')
        kb.doModal()
        if not kb.isConfirmed():
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        query = kb.getText().strip()
        if not query:
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        try:
            items = api.search(query)
        except Exception as e:
            return self._error(e)
        if not items:
            self._notify('Κανένα αποτέλεσμα.')
        self._add_items(items)
        xbmcplugin.setContent(self.handle, 'movies')
        xbmcplugin.setPluginCategory(self.handle, 'Αναζήτηση: {}'.format(query))
        xbmcplugin.endOfDirectory(self.handle)

    def show(self, custom_id):
        if not custom_id or not auth.require_auth():
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        try:
            detail = api.get_detail(custom_id)
        except Exception as e:
            return self._error(e)
        episodes = (detail or {}).get('episodes') or []
        self._add_items(episodes)
        xbmcplugin.setContent(self.handle, 'episodes')
        if detail:
            xbmcplugin.setPluginCategory(self.handle, detail.get('title', ''))
        xbmcplugin.endOfDirectory(self.handle)

    # --------------------------------------------------------------- actions

    def do_login(self):
        if auth.require_auth():
            self._notify('Συνδέθηκες.')
        xbmc.executebuiltin('Container.Refresh')

    def do_logout(self):
        auth.logout()
        self._notify('Αποσυνδέθηκες.')
        xbmc.executebuiltin('Container.Refresh')

    def toggle_mylist(self, magine_id, add):
        if not magine_id or not auth.require_auth():
            return
        try:
            api.set_mylist(magine_id, add=add)
            self._notify('Προστέθηκε στη λίστα.' if add
                         else 'Αφαιρέθηκε από τη λίστα.')
        except Exception as e:
            self._notify('Σφάλμα: {}'.format(e))
        xbmc.executebuiltin('Container.Refresh')

    # --------------------------------------------------------------- helpers

    def _add_items(self, items):
        for it in items:
            if not it:
                continue
            if it.get('kind') == 'show':
                self._add_folder(it)
            else:
                self._add_playable(it)

    def _add_folder(self, it):
        li = xbmcgui.ListItem(label=it.get('label') or it.get('title', ''))
        self._art(li, it)
        self._info(li, it)
        li.addContextMenuItems(self._context(it))
        xbmcplugin.addDirectoryItem(
            self.handle,
            self.url(action='show', custom=it.get('customId', '')),
            li, isFolder=True)

    def _add_playable(self, it):
        li = xbmcgui.ListItem(label=it.get('label') or it.get('title', ''))
        self._art(li, it)
        self._info(li, it)
        li.setProperty('IsPlayable', 'true')
        li.addContextMenuItems(self._context(it))
        xbmcplugin.addDirectoryItem(
            self.handle,
            self.url(action='play',
                     custom=it.get('customId', ''),
                     playable=it.get('playableId', ''),
                     title=it.get('title', ''),
                     offset=str(it.get('watchOffset', 0) or 0)),
            li, isFolder=False)

    def _art(self, li, it):
        poster = it.get('poster', '')
        banner = it.get('banner', '')
        li.setArt({
            'poster': poster or banner,
            'thumb': poster or banner,
            'landscape': banner,
            'fanart': banner or poster,
        })

    def _info(self, li, it):
        info = {
            'title': it.get('title', ''),
            'plot': it.get('plot', ''),
            'mediatype': 'movie' if it.get('kind') != 'show' else 'tvshow',
        }
        if it.get('year'):
            info['year'] = it['year']
        if it.get('duration'):
            info['duration'] = it['duration']
        if it.get('genres'):
            info['genre'] = it['genres']
        if it.get('directors'):
            info['director'] = it['directors']
        if it.get('kind') == 'episode':
            info['mediatype'] = 'episode'
            if it.get('season') is not None:
                info['season'] = it['season']
            if it.get('episode') is not None:
                info['episode'] = it['episode']
        li.setInfo('video', info)

    def _context(self, it):
        magine = it.get('magineId', '')
        if not magine or it.get('kind') == 'episode':
            return []
        if it.get('inMyList'):
            return [('Αφαίρεση από τη λίστα',
                     'RunPlugin({})'.format(
                         self.url(action='mylist', magine=magine, add='0')))]
        return [('Προσθήκη στη λίστα',
                 'RunPlugin({})'.format(
                     self.url(action='mylist', magine=magine, add='1')))]

    def _error(self, e):
        log('error: {}'.format(e))
        xbmcgui.Dialog().ok('Cinobo', 'Σφάλμα: {}'.format(e))
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)

    def _notify(self, msg):
        xbmcgui.Dialog().notification('Cinobo', msg,
                                      xbmcgui.NOTIFICATION_INFO, 3000)
