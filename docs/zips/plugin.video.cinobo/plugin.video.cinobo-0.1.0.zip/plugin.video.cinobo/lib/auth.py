"""Authentication for Cinobo (Magine Pro backend).

Login: POST client-api.magine.com/api/login/v2/auth/email with the constant
app access token in the Magine-AccessToken header and {identity, accessKey}
as JSON. The returned `token` (JWT) is used as `Authorization: Bearer` on all
subsequent API calls, together with the constant app token.

Tokens are persisted in the addon profile. A stable per-install device id is
generated once (needed by the playback preflight).
"""

import os
import json
import time
import string
import random

import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
TOKEN_FILE = os.path.join(PROFILE, 'session.json')

# Constant Cinobo app/tenant access token (hardcoded in the Cinobo frontend).
APP_TOKEN = '6c8cc9da-987a-4364-a348-b1cf4d857d42'
API_BASE = 'https://client-api.magine.com/api'
USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')


def log(msg):
    xbmc.log('[Cinobo] auth: {}'.format(msg), xbmc.LOGINFO)


def _ensure_profile():
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)


def _load():
    if not os.path.exists(TOKEN_FILE):
        return {}
    try:
        with open(TOKEN_FILE, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except (ValueError, OSError):
        return {}


def _save(data):
    _ensure_profile()
    with open(TOKEN_FILE, 'w', encoding='utf-8') as fh:
        json.dump(data, fh)


def device_id():
    """Return a stable per-install Magine-Play device id, creating it once."""
    data = _load()
    dev = data.get('device_id')
    if not dev:
        rnd = ''.join(random.choice(string.ascii_letters + string.digits)
                      for _ in range(20))
        dev = '4_' + rnd
        data['device_id'] = dev
        _save(data)
    return dev


def _requests():
    import requests
    return requests


def login(email, password):
    """Authenticate against Magine. Returns True on success.

    Stores the bearer token + user/profile ids. Raises RuntimeError with a
    user-facing message on failure.
    """
    requests = _requests()
    try:
        resp = requests.post(
            API_BASE + '/login/v2/auth/email',
            headers={
                'Magine-AccessToken': APP_TOKEN,
                'Content-Type': 'application/json',
                'User-Agent': USER_AGENT,
                'Origin': 'https://cinobo.com',
                'Referer': 'https://cinobo.com/',
            },
            json={'identity': email, 'accessKey': password},
            timeout=20,
        )
    except Exception as e:
        raise RuntimeError('Πρόβλημα σύνδεσης: {}'.format(e))

    if resp.status_code in (401, 403):
        raise RuntimeError('Λάθος email ή κωδικός.')
    if resp.status_code != 200:
        raise RuntimeError('Αποτυχία σύνδεσης (HTTP {}).'.format(resp.status_code))

    try:
        body = resp.json()
    except ValueError:
        raise RuntimeError('Μη έγκυρη απάντηση από τον server.')

    token = body.get('token')
    if not token:
        raise RuntimeError('Ο server δεν επέστρεψε token.')

    data = _load()
    data.update({
        'token': token,
        'session_id': body.get('sessionId'),
        'user_id': body.get('userId'),
        'profile_id': body.get('profileId'),
        'email': email,
        'saved_at': int(time.time()),
    })
    _save(data)
    log('login ok for user {}'.format(body.get('userId')))
    return True


def token():
    return _load().get('token')


def is_authenticated():
    return bool(token())


def logout():
    data = _load()
    for k in ('token', 'session_id', 'user_id', 'profile_id', 'email'):
        data.pop(k, None)
    _save(data)


def api_headers(extra=None):
    """Base headers for authenticated Magine API calls."""
    h = {
        'Magine-AccessToken': APP_TOKEN,
        'User-Agent': USER_AGENT,
        'Accept': 'application/json',
        'Origin': 'https://cinobo.com',
        'Referer': 'https://cinobo.com/',
    }
    tok = token()
    if tok:
        h['Authorization'] = 'Bearer ' + tok
    if extra:
        h.update(extra)
    return h


def require_auth():
    """Ensure we are logged in; try settings credentials, else prompt.

    Returns True if authenticated.
    """
    if is_authenticated():
        return True

    email = ADDON.getSetting('email').strip()
    password = ADDON.getSetting('password')
    if email and password:
        try:
            return login(email, password)
        except RuntimeError as e:
            xbmcgui.Dialog().ok('Cinobo', str(e))
            return False

    xbmcgui.Dialog().ok(
        'Cinobo',
        'Συμπλήρωσε email και κωδικό στις Ρυθμίσεις του add-on.'
    )
    ADDON.openSettings()
    email = ADDON.getSetting('email').strip()
    password = ADDON.getSetting('password')
    if not (email and password):
        return False
    try:
        return login(email, password)
    except RuntimeError as e:
        xbmcgui.Dialog().ok('Cinobo', str(e))
        return False
