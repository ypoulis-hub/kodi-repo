"""Cinobo backend API client (Magine Pro).

GraphQL ("apiql") for catalogue/viewables/lists, Meilisearch for search, and
the playback preflight for stream resolution. All endpoints verified against
the live API. See the project reference notes for the full map.
"""

import json

import xbmc

from . import auth

APIQL = auth.API_BASE + '/apiql/v2'
ENTITLEMENT = auth.API_BASE + '/entitlement/v2/asset/{}'
PREFLIGHT = auth.API_BASE + '/playback/v1/preflight/asset/{}'

# Root "startpage" view that lists all home rows (incl. Continue Watching &
# Watchlist blocks when authenticated).
HOME_VIEW = '0c40e410-ab1e-4cb8-ad05-7371175f2b49'

# Meilisearch (public search key from the Cinobo frontend).
SEARCH_URL = ('https://ms-b7d817340a95-27512.fra.meilisearch.io'
              '/indexes/catalog-v3/search')
SEARCH_KEY = 'bae68daab65f488503334c78f5241eca4bb6fdf1b0ec9258ab752d47b583f5f0'

# Collection block types that carry a `viewables` connection (rows of titles).
ROW_TYPES = (
    'SixteenNineCollection', 'PosterCollection', 'FeaturedCollection',
    'FeaturedCarouselCollection', 'ContinueWatchingCollection',
    'BookmarksCollection',
)


def log(msg):
    xbmc.log('[Cinobo] api: {}'.format(msg), xbmc.LOGINFO)


# --------------------------------------------------------------------- GraphQL

_VIEWABLE_FRAGMENT = """
fragment Vi on ViewableInterface {
  __typename
  ... on Movie {
    magineId customId title directors durationHuman productionYear genres inMyList description
    poster: image(type:"poster", width:400, height:592)
    banner: image(type:"sixteen-nine", width:768, height:432)
    defaultPlayable { __typename id ... on VodPlayable { duration watchOffset } }
  }
  ... on Show {
    magineId customId title directors productionYear genres inMyList description
    poster: image(type:"poster", width:400, height:592)
    banner: image(type:"sixteen-nine", width:768, height:432)
  }
  ... on Episode {
    magineId customId title seasonNumber episodeNumber description
    banner: image(type:"sixteen-nine", width:768, height:432)
    show { magineId customId title }
    defaultPlayable { __typename id ... on VodPlayable { duration watchOffset } }
  }
}
"""

_ROW = "title magineId viewables(first:$n){ pageInfo{hasNextPage endCursor} edges{ node{ ...Vi } } }"

_HOME_QUERY = ("""
query home($v: ID!, $n: Int!) {
  viewer { view(magineId: $v) { title
    blocks(first: 60, fetchMax: true) { edges { node {
      __typename
      ... on SixteenNineCollection { %R }
      ... on PosterCollection { %R }
      ... on FeaturedCollection { %R }
      ... on FeaturedCarouselCollection { %R }
      ... on ContinueWatchingCollection { %R }
      ... on BookmarksCollection { %R }
      ... on LinkCollection { title magineId }
    }}}
  }}
}
""".replace('%R', _ROW) + _VIEWABLE_FRAGMENT)

_BLOCK_QUERY = ("""
query block($id: ID!, $n: Int!, $after: String) {
  viewer { block(magineId: $id) {
    __typename
    ... on SixteenNineCollection { title viewables(first:$n, after:$after){ pageInfo{hasNextPage endCursor} edges{node{...Vi}} } }
    ... on PosterCollection { title viewables(first:$n, after:$after){ pageInfo{hasNextPage endCursor} edges{node{...Vi}} } }
    ... on FeaturedCollection { title viewables(first:$n, after:$after){ pageInfo{hasNextPage endCursor} edges{node{...Vi}} } }
    ... on FeaturedCarouselCollection { title viewables(first:$n, after:$after){ pageInfo{hasNextPage endCursor} edges{node{...Vi}} } }
    ... on ContinueWatchingCollection { title viewables(first:$n, after:$after){ pageInfo{hasNextPage endCursor} edges{node{...Vi}} } }
    ... on BookmarksCollection { title viewables(first:$n, after:$after){ pageInfo{hasNextPage endCursor} edges{node{...Vi}} } }
  }}
}
""" + _VIEWABLE_FRAGMENT)

_DETAIL_QUERY = ("""
query detail($c: ID!) {
  viewer { viewableCustomId(customId: $c) {
    ...Vi
    ... on Show {
      seasons { seasonNumber episodes {
        magineId customId title seasonNumber episodeNumber description durationHuman
        banner: image(type:"sixteen-nine", width:768, height:432)
        defaultPlayable { __typename id ... on VodPlayable { duration watchOffset } }
      } }
    }
  }}
}
""" + _VIEWABLE_FRAGMENT)


def _gql(query, variables=None):
    import requests
    resp = requests.post(
        APIQL,
        headers=auth.api_headers({'Content-Type': 'application/json'}),
        json={'query': query, 'variables': variables or {}},
        timeout=20,
    )
    if resp.status_code == 403:
        # token likely expired — clear it so the next call re-logs-in
        auth.logout()
        raise RuntimeError('Η συνεδρία έληξε. Δοκίμασε ξανά.')
    resp.raise_for_status()
    data = resp.json()
    if data.get('errors'):
        log('GraphQL errors: {}'.format(json.dumps(data['errors'])[:300]))
    return data.get('data') or {}


# ----------------------------------------------------------------- parsing

def _img(url, width=None, height=None):
    return url or ''


def parse_viewable(node):
    """Normalise a Movie/Show/Episode GraphQL node into a flat dict."""
    if not node:
        return None
    kind = node.get('__typename', '')
    playable = node.get('defaultPlayable') or {}
    show = node.get('show') or {}
    title = node.get('title', '')
    if kind == 'Episode' and show.get('title'):
        label = '{} - {}'.format(show['title'], title)
    else:
        label = title
    return {
        'kind': kind.lower(),
        'magineId': node.get('magineId', ''),
        'customId': node.get('customId', ''),
        'title': title,
        'label': label,
        'plot': node.get('description', '') or '',
        'year': node.get('productionYear'),
        'duration': (playable.get('duration')
                     or _dur_seconds(node.get('durationHuman'))),
        'directors': node.get('directors') or [],
        'genres': node.get('genres') or [],
        'poster': node.get('poster') or node.get('banner') or '',
        'banner': node.get('banner') or node.get('poster') or '',
        'inMyList': bool(node.get('inMyList')),
        'playableId': playable.get('id') or '',
        'watchOffset': playable.get('watchOffset') or 0,
        'season': node.get('seasonNumber'),
        'episode': node.get('episodeNumber'),
    }


def _dur_seconds(human):
    """Best-effort parse of '1h 10min' style strings to seconds."""
    if not human:
        return 0
    import re
    h = re.search(r'(\d+)\s*h', human)
    m = re.search(r'(\d+)\s*m', human)
    return (int(h.group(1)) * 3600 if h else 0) + (int(m.group(1)) * 60 if m else 0)


def _row_items(node, n):
    edges = (node.get('viewables') or {}).get('edges') or []
    return [parse_viewable(e['node']) for e in edges if e.get('node')]


# ----------------------------------------------------------------- public API

def get_home(items_per_row=30):
    """Return home rows: list of {type, title, id, items[], special}."""
    data = _gql(_HOME_QUERY, {'v': HOME_VIEW, 'n': items_per_row})
    view = ((data.get('viewer') or {}).get('view') or {})
    rows = []
    for edge in (view.get('blocks') or {}).get('edges', []):
        node = edge.get('node') or {}
        t = node.get('__typename')
        if t in ROW_TYPES:
            items = _row_items(node, items_per_row)
            if not items:
                continue
            rows.append({
                'type': t,
                'title': node.get('title') or '',
                'id': node.get('magineId') or '',
                'items': items,
            })
    return rows


def get_special_row(typename, items_per_row=60):
    """Return the items of a single special home block (Watchlist / Continue)."""
    for row in get_home(items_per_row):
        if row['type'] == typename:
            return row['items']
    return []


def get_watchlist():
    return get_special_row('BookmarksCollection')


def get_continue_watching():
    return get_special_row('ContinueWatchingCollection')


def get_block(block_id, after=None, n=40):
    """Paginated viewables of one collection. Returns (items, next_cursor)."""
    data = _gql(_BLOCK_QUERY, {'id': block_id, 'n': n, 'after': after})
    node = (data.get('viewer') or {}).get('block') or {}
    vs = node.get('viewables') or {}
    items = [parse_viewable(e['node']) for e in vs.get('edges', []) if e.get('node')]
    page = vs.get('pageInfo') or {}
    nxt = page.get('endCursor') if page.get('hasNextPage') else None
    return items, nxt


def get_detail(custom_id):
    """Full detail for a title by customId (incl. episodes for Shows)."""
    data = _gql(_DETAIL_QUERY, {'c': custom_id})
    node = (data.get('viewer') or {}).get('viewableCustomId') or {}
    if not node:
        return None
    item = parse_viewable(node)
    if node.get('__typename') == 'Show':
        episodes = []
        for season in node.get('seasons') or []:
            for ep in season.get('episodes') or []:
                episodes.append(parse_viewable(ep))
        item['episodes'] = episodes
    return item


def search(query, limit=60):
    """Meilisearch full-text search. Returns list of flat item dicts."""
    import requests
    body = {
        'q': query,
        'limit': limit,
        'offset': 0,
        'filter': 'isPublished = true',
        'matchingStrategy': 'frequency',
        'attributesToRetrieve': [
            'id', 'magineId', 'customId', 'title_en', 'title_el', 'type',
            'year', 'sixteenNine', 'genres_en', 'genres_el', 'directors_en',
            'directors_el', 'description_en', 'description_el',
        ],
    }
    resp = requests.post(
        SEARCH_URL,
        headers={
            'Authorization': 'Bearer ' + SEARCH_KEY,
            'Content-Type': 'application/json',
            'User-Agent': auth.USER_AGENT,
            'Origin': 'https://cinobo.com',
        },
        json=body, timeout=20,
    )
    resp.raise_for_status()
    hits = resp.json().get('hits', [])
    out = []
    for h in hits:
        img = h.get('sixteenNine') or ''
        if img and img.startswith('/'):
            img = 'https://images.eu-west-1.prod.magine.com' + img
        out.append({
            'kind': h.get('type', 'movie'),
            'magineId': h.get('magineId', ''),
            'customId': h.get('customId', ''),
            'title': h.get('title_el') or h.get('title_en') or '',
            'label': h.get('title_el') or h.get('title_en') or '',
            'plot': h.get('description_el') or h.get('description_en') or '',
            'year': h.get('year'),
            'duration': 0,
            'directors': h.get('directors_el') or h.get('directors_en') or [],
            'genres': h.get('genres_el') or h.get('genres_en') or [],
            'poster': img,
            'banner': img,
            'inMyList': False,
            'playableId': '',
            'watchOffset': 0,
        })
    return out


def get_navigation(locale='el'):
    """CMS navigation: curated Collections/Filmographies. Returns list of
    {title, magineId} link entries under each top-level LinkCollection."""
    import requests
    resp = requests.post(
        'https://cinobo.com/api/cms/navigation/getNavigation',
        headers={'Content-Type': 'application/json', 'User-Agent': auth.USER_AGENT},
        json={'locale': locale}, timeout=20,
    )
    resp.raise_for_status()
    groups = []
    for col in resp.json().get('collection', []):
        links = []
        for e in (col.get('links') or {}).get('edges', []):
            n = e.get('node') or {}
            links.append({'title': n.get('title', ''),
                          'magineId': n.get('magineId', ''),
                          'image': n.get('image', '')})
        if links:
            groups.append({'title': col.get('title', ''), 'links': links})
    return groups


def set_mylist(magine_id, add=True):
    op = 'addToMyList' if add else 'removeFromMyList'
    q = ('mutation m($id: String!) { %s(input:{viewableId:$id}) { viewableId } }'
         % op)
    _gql(q, {'id': magine_id})


# ---------------------------------------------------------------------- playback

def _entitlement_token(playable_id):
    """Fetch the per-asset entitlement token required by the preflight.

    Without the resulting Magine-Play-EntitlementId header the preflight
    misleadingly returns ForbiddenGeolocation.
    """
    import requests
    headers = auth.api_headers({'Content-Type': 'application/json'})
    resp = requests.post(
        ENTITLEMENT.format(playable_id), headers=headers, json={}, timeout=20)
    if resp.status_code in (401, 403):
        auth.logout()
        raise RuntimeError('Χρειάζεται σύνδεση.')
    if resp.status_code != 200:
        try:
            err = resp.json().get('error', {})
            msg = err.get('user_message') or err.get('message')
        except ValueError:
            msg = None
        raise RuntimeError('Η συνδρομή δεν καλύπτει αυτόν τον τίτλο.'
                           if resp.status_code == 400 and not msg
                           else 'Σφάλμα entitlement: {}'.format(msg or resp.status_code))
    return resp.json().get('token', '')


def get_playback(playable_id):
    """Resolve a VOD playable. Returns dict with manifest + license + headers.

    Flow: entitlement/v2/asset -> preflight (with the entitlement token in the
    Magine-Play-EntitlementId header). Raises RuntimeError on failure.
    """
    import requests
    entitlement = _entitlement_token(playable_id)
    play_headers = {
        'Magine-Play-DeviceId': auth.device_id(),
        'Magine-Play-DeviceModel': 'Kodi',
        'Magine-Play-DevicePlatform': 'web',
        'Magine-Play-DeviceType': 'web',
        'Magine-Play-Protocol': 'dashs',
        'Magine-Play-DRM': 'widevine',
        'Magine-Play-EntitlementId': entitlement,
    }
    headers = auth.api_headers(play_headers)
    headers['Content-Type'] = 'application/json'
    resp = requests.post(
        PREFLIGHT.format(playable_id), headers=headers, json={}, timeout=20,
    )
    if resp.status_code == 200:
        body = resp.json()
        return {
            'manifest': body.get('playlist'),
            'license': body.get('license'),
            'heartbeat': body.get('heartbeat'),
            'play_headers': body.get('headers') or play_headers,
        }
    # error handling
    try:
        err = resp.json().get('error', {})
        msg = err.get('user_message') or err.get('message') or ''
        code = err.get('code')
    except ValueError:
        msg, code = '', resp.status_code
    if code == 521 or 'Geolocation' in str(msg):
        raise RuntimeError('Δεν είναι διαθέσιμο στην περιοχή σου '
                           '(geo-block). Απενεργοποίησε τυχόν VPN.')
    if resp.status_code in (401, 403):
        auth.logout()
        raise RuntimeError('Χρειάζεται σύνδεση ή η συνδρομή δεν καλύπτει '
                           'αυτόν τον τίτλο.')
    raise RuntimeError('Αποτυχία αναπαραγωγής: {}'.format(msg or resp.status_code))
