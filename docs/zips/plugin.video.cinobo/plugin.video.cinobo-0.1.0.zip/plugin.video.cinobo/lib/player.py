"""Playback for Cinobo via inputstream.adaptive + Widevine.

Resolves a title to its DASH manifest + Widevine license via the Magine
playback preflight, then hands off to inputstream.adaptive. The license POST
carries the Magine auth + per-session play headers returned by preflight.
"""

import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from . import api, auth

ADDON = xbmcaddon.Addon()


def log(msg):
    xbmc.log('[Cinobo] player: {}'.format(msg), xbmc.LOGINFO)


def _fail(handle, msg=None):
    if msg:
        xbmcgui.Dialog().ok('Cinobo', msg)
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def play(handle, custom_id='', playable_id='', title='', offset=0):
    if not auth.require_auth():
        return _fail(handle)

    if not _check_inputstream():
        return _fail(handle,
                     'Το inputstream.adaptive απαιτείται για την αναπαραγωγή '
                     'αλλά δεν είναι διαθέσιμο. Εγκατέστησέ το από τον '
                     'Add-on manager.')

    # Resolve a playable id if we only have a customId.
    if not playable_id and custom_id:
        try:
            detail = api.get_detail(custom_id)
        except Exception as e:
            return _fail(handle, 'Σφάλμα ανάκτησης τίτλου: {}'.format(e))
        if not detail or not detail.get('playableId'):
            return _fail(handle, 'Δεν βρέθηκε διαθέσιμη ροή για αυτόν τον τίτλο.')
        playable_id = detail['playableId']
        title = title or detail.get('title', '')
        offset = offset or detail.get('watchOffset', 0)

    if not playable_id:
        return _fail(handle, 'Λείπει το αναγνωριστικό ροής.')

    try:
        pb = api.get_playback(playable_id)
    except RuntimeError as e:
        return _fail(handle, str(e))
    except Exception as e:
        return _fail(handle, 'Αποτυχία αναπαραγωγής: {}'.format(e))

    manifest = pb.get('manifest')
    if not manifest:
        return _fail(handle, 'Ο server δεν επέστρεψε ροή.')

    log('play playable={} manifest={}'.format(playable_id, manifest[:70]))
    item = xbmcgui.ListItem(path=manifest, offscreen=True)
    item.setInfo('video', {'title': title, 'mediatype': 'movie'})

    _configure_isa(item, pb)

    # Resume point (continue watching)
    try:
        if offset and int(offset) > 0:
            item.setProperty('ResumeTime', str(int(offset)))
            item.setProperty('TotalTime', '1')
    except (TypeError, ValueError):
        pass

    xbmcplugin.setResolvedUrl(handle, True, item)


def _check_inputstream():
    try:
        return xbmcaddon.Addon('inputstream.adaptive') is not None
    except RuntimeError:
        return False


def _configure_isa(item, pb):
    """Attach inputstream.adaptive + Widevine properties to the ListItem."""
    license_url = pb.get('license') or ''
    play_headers = pb.get('play_headers') or {}

    # Headers the CDN / manifest fetch should carry.
    stream_headers = _encode({'User-Agent': auth.USER_AGENT})

    # Headers the Widevine license POST must carry: Magine auth + the
    # per-session play headers returned by preflight.
    lic_headers = {
        'Magine-AccessToken': auth.APP_TOKEN,
        'User-Agent': auth.USER_AGENT,
        'Content-Type': 'application/octet-stream',
    }
    tok = auth.token()
    if tok:
        lic_headers['Authorization'] = 'Bearer ' + tok
    for k, v in play_headers.items():
        if v is not None:
            lic_headers[str(k)] = str(v)

    try:
        item.setContentLookup(False)
        item.setMimeType('application/dash+xml')
    except AttributeError:
        pass

    props = {
        'inputstream': 'inputstream.adaptive',
        'inputstream.adaptive.manifest_type': 'mpd',
        'inputstream.adaptive.stream_headers': stream_headers,
    }
    if license_url:
        props['inputstream.adaptive.license_type'] = 'com.widevine.alpha'
        props['inputstream.adaptive.license_key'] = '{}|{}|R{{SSM}}|'.format(
            license_url, _encode(lic_headers))

    for k, v in props.items():
        item.setProperty(k, v)


def _encode(headers):
    return '&'.join(
        '{}={}'.format(urllib.parse.quote(str(k), safe=''),
                       urllib.parse.quote(str(v), safe=''))
        for k, v in headers.items()
    )
