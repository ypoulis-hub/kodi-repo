"""Cinobo - Kodi video add-on.

Browse and play films from your Cinobo subscription.
Uses the Cinobo API + DASH/HLS streams via inputstream.adaptive.
"""

import sys
import urllib.parse

from lib.navigation import Router

handle = int(sys.argv[1])
base_url = sys.argv[0]
args = sys.argv[2][1:] if len(sys.argv) > 2 else ''
params = dict(urllib.parse.parse_qsl(args))

router = Router(handle, base_url)
router.route(params)
